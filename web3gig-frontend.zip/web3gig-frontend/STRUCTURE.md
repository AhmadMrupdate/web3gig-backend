# 📁 Web3Gig Repository Structure

Complete guide on how to organize Web3Gig files for GitHub and deployment.

---

## 📦 Recommended Folder Structure

```
web3gig/
│
├── 📄 index.html                    ← Home/Landing Page
├── 📄 gigs.html                     ← Gigs Marketplace Page
├── 📄 dashboard.html                ← Dashboard Page
├── 📄 profile.html                  ← Freelancer Profile Page
├── 📄 admin.html                    ← Admin Panel Page
├── 📄 job-chat-payment.html         ← Job Board + Chat + Wallet
│
├── 📁 css/                          ← All CSS files
│   ├── style.css                    ← Main stylesheet (shared across all pages)
│   ├── theme.css                    ← Theme variables & colors (optional)
│   └── responsive.css               ← Mobile breakpoints (optional)
│
├── 📁 js/                           ← All JavaScript files
│   ├── app.js                       ← Main app initialization
│   ├── auth.js                      ← Login/Register logic
│   ├── nav.js                       ← Navigation & menu handling
│   ├── pages.js                     ← Page switching logic
│   ├── filters.js                   ← Gig filtering & search
│   ├── modals.js                    ← Modal management
│   ├── utils.js                     ← Helper functions
│   ├── counters.js                  ← Animated counters
│   ├── dashboard.js                 ← Dashboard specific logic
│   └── admin.js                     ← Admin panel logic
│
├── 📁 assets/                       ← Media & resources
│   ├── images/                      ← PNG, JPG, SVG files (future)
│   ├── icons/                       ← Icon files (future)
│   └── fonts/                       ← Custom fonts (optional, Google Fonts used)
│
├── 📄 README.md                     ← Project documentation
├── 📄 DEPLOY.md                     ← Deployment guide
├── 📄 STRUCTURE.md                  ← This file (folder organization)
├── 📄 .gitignore                    ← Files to ignore in Git
├── 📄 LICENSE                       ← MIT License
└── 📄 robots.txt                    ← Search engine guide (future)
```

---

## 📄 File Descriptions

### HTML Files (Root Level)

Each HTML file is **independent** but can link to others:

| File | Size | Purpose |
|------|------|---------|
| `index.html` | ~50KB | Landing page with hero, categories, testimonials |
| `gigs.html` | ~45KB | Browse & filter gigs marketplace |
| `dashboard.html` | ~40KB | Freelancer/Client dashboard |
| `profile.html` | ~35KB | Public freelancer profile with reviews |
| `admin.html` | ~60KB | Admin panel with user & dispute management |
| `job-chat-payment.html` | ~50KB | Job board, live chat, wallet, transactions |

---

## 🎨 CSS Organization

### `css/style.css` (Main - ~5KB)

Contains:
- CSS variables (colors, fonts, sizes)
- Base styles (*, html, body)
- Typography (headings, paragraphs)
- Components (buttons, cards, modals)
- Layout (flexbox, grid)
- Animations (transitions, keyframes)
- Responsive (media queries)

**Example structure:**
```css
/* Variables */
:root {
  --black: #02040a;
  --purple: #8b30ff;
  /* ... more variables */
}

/* Base Styles */
* { box-sizing: border-box; }
body { background: var(--black); }

/* Components */
.btn { padding: 0.5rem; }
.card { border: 1px solid var(--border); }

/* Responsive */
@media (max-width: 900px) {
  /* tablet styles */
}
```

### `css/theme.css` (Optional - ~2KB)

If you want to separate theme:
```css
:root {
  --primary: #8b30ff;
  --secondary: #00f5ff;
  /* ... theme colors only */
}
```

### `css/responsive.css` (Optional - ~1KB)

Mobile-specific styles:
```css
@media (max-width: 600px) {
  .nav-links { display: none; }
  .grid { grid-template-columns: 1fr; }
}
```

---

## ⚙️ JavaScript Organization

### `js/app.js` - Main Entry Point

```javascript
// Global initialization
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initAuth();
  initPages();
  initModals();
  setupEventListeners();
});

// Global functions
function toast(msg) { /* ... */ }
function showToast(msg) { /* ... */ }
```

### `js/auth.js` - Authentication

```javascript
function openLoginModal() { /* ... */ }
function loginSuccess() { /* ... */ }
function registerSuccess() { /* ... */ }
function logout() { /* ... */ }
function validateEmail(email) { /* ... */ }
```

### `js/nav.js` - Navigation

```javascript
function initNav() { /* ... */ }
function toggleMobileMenu() { /* ... */ }
function setActiveNav(page) { /* ... */ }
```

### `js/pages.js` - Page Management

```javascript
function showPage(id) { /* ... */ }
function getCurrentPage() { /* ... */ }
function getPagePath(page) { /* ... */ }
```

### `js/filters.js` - Search & Filter

```javascript
function filterGigs() { /* ... */ }
function searchGigs(query) { /* ... */ }
function applyFilters(filters) { /* ... */ }
function tagFilter(tag) { /* ... */ }
function sortGigs(sortBy) { /* ... */ }
```

### `js/modals.js` - Modal Management

```javascript
function openModal(type) { /* ... */ }
function closeModal(type) { /* ... */ }
function toggleModal(id) { /* ... */ }
function setupModals() { /* ... */ }
```

### `js/utils.js` - Utility Functions

```javascript
// Storage
function saveToLocalStorage(key, value) { /* ... */ }
function getFromLocalStorage(key) { /* ... */ }

// DOM manipulation
function createElement(type, class, html) { /* ... */ }
function toggleClass(el, className) { /* ... */ }

// Validation
function isValidEmail(email) { /* ... */ }
function isValidURL(url) { /* ... */ }

// Formatting
function formatPrice(amount) { /* ... */ }
function formatDate(date) { /* ... */ }
```

### `js/counters.js` - Animated Numbers

```javascript
function animateCounter(elementId, target, prefix, suffix) {
  // Smoothly animate number from 0 to target
}

function startCounters() {
  animateCounter('h1', 52400);
  animateCounter('h2', 148000);
  // etc...
}
```

### `js/dashboard.js` - Dashboard Logic

```javascript
function initDashboard() { /* ... */ }
function loadUserData() { /* ... */ }
function switchRole(role) { /* ... */ }
function updateStats() { /* ... */ }
function loadOrders() { /* ... */ }
```

### `js/admin.js` - Admin Panel Logic

```javascript
function initAdmin() { /* ... */ }
function loadUsers() { /* ... */ }
function deleteUser(userId) { /* ... */ }
function resolveDispute(disputeId) { /* ... */ }
function banUser(userId) { /* ... */ }
```

---

## 📁 Assets Folder (For Future)

```
assets/
├── images/
│   ├── logo.png
│   ├── hero-bg.jpg
│   ├── freelancer-1.jpg
│   └── freelancer-2.jpg
├── icons/
│   ├── ethereum.svg
│   ├── solana.svg
│   ├── pi-network.svg
│   └── ton.svg
└── fonts/
    ├── orbitron.ttf
    ├── exo-2.ttf
    └── share-tech-mono.ttf
```

---

## 🔗 How to Link Files in HTML

### From Root HTML to CSS
```html
<link rel="stylesheet" href="css/style.css">
```

### From Root HTML to JS
```html
<script src="js/app.js"></script>
<script src="js/auth.js"></script>
<script src="js/nav.js"></script>
<script src="js/pages.js"></script>
<script src="js/filters.js"></script>
<script src="js/modals.js"></script>
<script src="js/utils.js"></script>
<script src="js/counters.js"></script>
```

### Loading Order Matters!
```html
<!-- Load utilities first (no dependencies) -->
<script src="js/utils.js"></script>
<script src="js/counters.js"></script>

<!-- Then components -->
<script src="js/modals.js"></script>
<script src="js/auth.js"></script>
<script src="js/filters.js"></script>

<!-- Then main app (depends on everything else) -->
<script src="js/app.js"></script>
```

---

## 📝 File Naming Conventions

**HTML:**
- `index.html` - Home page (must be named this!)
- `about.html` - About page
- `gigs.html` - Gigs page
- kebab-case for multiple words: `job-board.html`

**CSS:**
- `style.css` - Main stylesheet
- `theme.css` - Theme/variables
- `responsive.css` - Mobile styles
- kebab-case: `dark-theme.css`

**JavaScript:**
- `app.js` - Main app file
- `utils.js` - Utilities/helpers
- camelCase for functions: `openModal()`, `closeModal()`
- kebab-case for files: `auth.js`, `nav.js`, `page-router.js`

**Images:**
- `logo.png` - Logo
- `hero-bg.jpg` - Background image
- kebab-case: `freelancer-avatar.jpg`

---

## 🚀 Adding a New Page

To add a new page (e.g., `messages.html`):

1. **Create HTML file in root:**
   ```bash
   touch messages.html
   ```

2. **Copy structure from existing page** (e.g., gigs.html)

3. **Update navigation** in `js/nav.js`:
   ```javascript
   function initNav() {
     navLinks.forEach(link => {
       if(link.id === 'nl-messages') {
         link.addEventListener('click', () => showPage('messages'));
       }
     });
   }
   ```

4. **Add page switching** in `js/pages.js`:
   ```javascript
   function showPage(id) {
     if(id === 'messages') {
       document.getElementById('page-messages').style.display = 'block';
     }
   }
   ```

5. **Create JS file** if needed:
   ```bash
   touch js/messages.js
   ```

6. **Link in HTML:**
   ```html
   <script src="js/messages.js"></script>
   ```

---

## 📦 GitHub Upload Instructions

### Using Git Command Line

```bash
# Navigate to project folder
cd web3gig

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Web3Gig marketplace"

# Add remote (replace with your GitHub URL)
git remote add origin https://github.com/yourusername/web3gig.git

# Rename branch to main
git branch -M main

# Push to GitHub
git push -u origin main
```

### Using GitHub Desktop (GUI)

1. Open GitHub Desktop
2. File → Clone Repository
3. Select local path
4. Publish repository
5. Files auto-upload!

---

## 🔐 Important Files Not to Commit

Covered by `.gitignore`:
- `node_modules/` - Never committed
- `.env` files - Contains secrets
- `dist/` or `build/` - Auto-generated
- `.DS_Store` - macOS junk
- `Thumbs.db` - Windows junk

---

## 📊 File Size Summary

```
Total Project Size: ~350KB (uncompressed)

Breakdown:
├── HTML files:        ~280KB (6 × 45KB avg)
├── CSS files:         ~10KB  (style.css)
├── JS files:          ~50KB  (8 files × 6KB avg)
└── Assets:            ~10KB  (icons, future images)

Compressed (gzip):     ~40KB
Typical Page Load:     <1 second (on 5G/Fiber)
```

---

## 🎯 Best Practices

✅ **DO:**
- Keep files organized in folders
- Use relative paths (`css/style.css`)
- Name files descriptively
- Comment complex code
- Keep HTML clean
- Separate concerns (HTML ≠ CSS ≠ JS)
- Use CSS variables for theming
- Test locally before pushing

❌ **DON'T:**
- Mix HTML/CSS/JS in one file
- Use absolute paths (`/css/style.css`)
- Create random folder names
- Leave commented code
- Have huge 10MB files
- Commit `node_modules/`
- Use deprecated code
- Deploy without testing

---

## 🔄 Updating Files

### Local Workflow

```bash
# Make changes to files
nano js/app.js

# Check status
git status

# Stage changes
git add .

# Commit
git commit -m "Fix: Update counter logic"

# Push to GitHub
git push origin main

# Automatic deployment! (if using Netlify/Vercel)
```

---

## 📚 Quick Reference

| Need | File |
|------|------|
| Change colors/theme | `css/style.css` (`:root` variables) |
| Add new page | Create `.html` + update nav in `js/nav.js` |
| Fix bug | Find in respective JS file |
| Update homepage | `index.html` |
| Change fonts | `css/style.css` (import or CSS vars) |
| Add feature | New JS file in `js/` folder |
| Mobile styles | Bottom of `css/style.css` (media queries) |

---

## ✅ Before Going Live

- [ ] All HTML files in root directory
- [ ] CSS linked in each HTML
- [ ] All JS files in `js/` folder
- [ ] No broken links between pages
- [ ] Test responsive design
- [ ] Check console for errors (F12)
- [ ] Update README.md
- [ ] Create .gitignore
- [ ] Add LICENSE (MIT)
- [ ] Test all modals
- [ ] Test all forms
- [ ] Verify image paths
- [ ] Commit to GitHub
- [ ] Deploy to Netlify/Vercel

---

**Happy organizing! 🚀**

*This structure works for both local development and production deployment.*
